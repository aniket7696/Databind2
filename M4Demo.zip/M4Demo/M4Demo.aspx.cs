﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace M4Demo
{
    public partial class M4Demo : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        int records = 0;
        string strcbl1 = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
                PopulateUI();
        }
        public void PopulateUI()
        {
            cmd = new SqlCommand("select * from aish164277.Demo", con);
            con.Open();
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            if (dr.HasRows)
                dt.Load(dr);
            con.Close();
            gvDemo.DataSource = dt;
            gvDemo.DataBind();
        }

        public int getCount()
        {
            cmd = new SqlCommand("Select * from aish164277.Demo", con);
            con.Open();
            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    records++;
                }

            }

            con.Close();
            return records;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("insert into aish164277.Demo(stu_Id, stu_name,dob,contact,stu_Password, repassword,gender,city,Hobbies) values (@stu_Id,@stu_name,@dob,@contact,@stu_Password,@repassword,@gender,@city,@Hobbies)", con);
            cmd.Parameters.AddWithValue("@stu_Id", txtId.Text);
            cmd.Parameters.AddWithValue("@stu_name", txtName.Text);
            cmd.Parameters.AddWithValue("@dob", txtDOB.Text);
            cmd.Parameters.AddWithValue("@contact", txtContact.Text);
            cmd.Parameters.AddWithValue("@stu_Password", txtPassword.Text);
            cmd.Parameters.AddWithValue("@repassword", txtREPassword.Text);
            cmd.Parameters.AddWithValue("@gender", gender.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@city", city.SelectedItem.Text);
            for (int i = 0; i < chkHobbies.Items.Count - 1; i++)
            {
                if (chkHobbies.Items[i].Selected == true)
                {
                    strcbl1 = strcbl1 + chkHobbies.Items[i].Value.ToString() + ",";
                }
            }
            cmd.Parameters.AddWithValue("@Hobbies", strcbl1);
            con.Open();
            int recordaffected = cmd.ExecuteNonQuery();
            con.Close();
            if (recordaffected > 0)
            {
                Response.Write("<script type='text/javascript'>alert('Record Inserted Successfully')</script>");
                PopulateUI();

            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('Record Not Inserted Successfully')</script>");
            }


        }
        
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("delete from aish164277.Demo where stu_Id=@stu_Id ", con);
            cmd.Parameters.AddWithValue("@stu_Id", Convert.ToInt32(txtId.Text));
            con.Open();
            int recordaffected = cmd.ExecuteNonQuery();
            con.Close();
            if (recordaffected > 0)
            {
                Response.Write("<script type='text/javascript'>alert('Student Record Deleted Successfully')</script>");
                PopulateUI();

            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('Student Record Not Deleted Successfully')</script>");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("update aish164277.Demo set stu_Id=@stu_Id, stu_name=@stu_name,dob=@dob,contact=@contact,stu_Password=@stu_Password, repassword=@repassword,gender=@gender,cit=@city,Hobbies=@Hobbies", con);
            cmd.Parameters.AddWithValue("@stu_Id", txtId.Text);
            cmd.Parameters.AddWithValue("@stu_name", txtName.Text);
            cmd.Parameters.AddWithValue("@dob", txtDOB.Text);
            cmd.Parameters.AddWithValue("@contact", txtContact.Text);
            cmd.Parameters.AddWithValue("@stu_Password", txtPassword.Text);
            cmd.Parameters.AddWithValue("@repassword", txtREPassword.Text);
            cmd.Parameters.AddWithValue("@gender", gender.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@city", city.SelectedItem.Text);
            for (int i = 0; i < chkHobbies.Items.Count - 1; i++)
            {
                if (chkHobbies.Items[i].Selected == true)
                {
                    strcbl1 = strcbl1 + chkHobbies.Items[i].Value.ToString() + ",";
                }
            }
            cmd.Parameters.AddWithValue("@Hobbies", strcbl1);
            con.Open();
            int recordaffected = cmd.ExecuteNonQuery();
            con.Close();
            if (recordaffected > 0)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated Successfully')</script>");
                PopulateUI();

            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('Record Not Updated Successfully')</script>");
            }

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("SELECT * FROM aish164277.Demo WHERE stu_Id=@stu_Id", con);
            cmd.Parameters.AddWithValue("@stu_Id", txtId.Text);
            con.Open();
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            if (dr.HasRows)
                dt.Load(dr);
            con.Close();
            gvDemo.DataSource = dt;
            gvDemo.DataBind();
        }

        protected void btnCount_Click(object sender, EventArgs e)
        {
            lblCount.Text= Convert.ToString(getCount());
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtName.Text = "";
            txtDOB.Text = "";
            txtContact.Text = "";
            txtPassword.Text = "";
            txtREPassword.Text = "";
           
        }
    }
}